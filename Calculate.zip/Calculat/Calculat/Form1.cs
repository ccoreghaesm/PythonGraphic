﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
namespace Calculat
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string First_Number = textBox1.Text;
            string Secend_Number = textBox2.Text;
            char Operator='a';
            if (comboBox1.SelectedIndex == 0)
                Operator = '+';
            else if(comboBox1.SelectedIndex == 1)
                Operator = '-';
            else if (comboBox1.SelectedIndex == 2)
                Operator = '/';
            else if (comboBox1.SelectedIndex == 3)
                Operator = '*';
            else if (comboBox1.SelectedIndex == 4)
                Operator = '^';
            File.WriteAllText("SendToCPlus.txt", First_Number + "|" + Secend_Number + "|" + Operator);
            System.Diagnostics.Process oProcess = new System.Diagnostics.Process();
            oProcess.StartInfo.Arguments = "";
            oProcess.StartInfo.FileName = "Main.exe";
            oProcess.StartInfo.WorkingDirectory = "";
            oProcess.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try{
            textBox3.Text = File.ReadAllText("SendToCSharp.txt");}
            catch{

            }
        }
    }
}
